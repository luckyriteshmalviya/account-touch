export const rolesOptions = [
    { value: "1", text: "Super Admin", selected: false },
    { value: "2", text: "Checker", selected: false },
    { value: "3", text: "Maker", selected: false },
    { value: "4", text: "Franchise", selected: false },
    { value: "5", text: "Client", selected: false },
];


export const assignedToOptions = [
    { value: "1", text: "Checker 1", selected: false },
    { value: "2", text: "Checker 2", selected: false },

];

export const priorityToOptions = [
    { value: "1", text: "Low", selected: false },
    { value: "2", text: "Medium", selected: false },
    { value: "3", text: "High", selected: false },
    { value: "4", text: "Urgent", selected: false },

];